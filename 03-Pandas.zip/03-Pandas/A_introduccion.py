# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""

nombre = "Adrian"
numero = 3
lista = [1,2,3]
tupla = (4,5,6)
diccionario = {
        "nombre":"A",
        "cedula":"1",
        }